# NMA A2U Interface

This repository develops and demonstrates the **Agent-to-User (A2U) interface**
for a Network Management Agent (NMA).

A2U is a user-facing interface through which a **non-agent upper-layer system or
user**—for example, an OSS/BSS, orchestrator, management portal, automation
system, or human-facing application—discovers and invokes NMA capabilities.
Communication between two NMAs or agents is outside the scope of A2U and is
expected to use A2A or another Agent-to-Agent interface.

## Related Internet-Drafts

- [AI based Network Management Agent (NMA): Concepts and Architecture](https://datatracker.ietf.org/doc/draft-zhao-nmop-network-management-agent/)
- [Framework and YANG Data Model for the NMA A2U Interface](https://datatracker.ietf.org/doc/draft-zhao-nmop-nma-a2u-yang/)

The A2U YANG model covers:

- NMA capability discovery;
- natural-language and structured intent submission;
- intent and task operational-state access;
- execution-plan exposure;
- human-in-the-loop confirmation;
- task abort;
- task progress and completion notifications;
- consistent error information.

## IETF 126 Hackathon Demo

The [`hackathon-demo`](./hackathon-demo/) directory contains a deterministic,
self-contained implementation used to demonstrate the NMA concept and the A2U
YANG model at the IETF 126 Hackathon.

The demo contains two logical systems:

1. **OSS/BSS Simulator — A2U Client**  
   A non-agent upper-layer system that discovers NMA capabilities, submits an
   intent, observes task progress, retrieves confirmation context, and resolves
   human-in-the-loop decisions.

2. **Domain Controller with an Embedded NMA — A2U Server**  
   The NMA interprets the intent, obtains network context through controller
   functions, performs analysis and planning, requests confirmation, invokes
   controller execution functions, verifies the result, and reports feedback.

### OSS/BSS A2U client

![OSS/BSS A2U client](docs/images/oss-a2u-client.png)

### Domain controller and embedded NMA

![Domain controller and embedded NMA](docs/images/domain-controller.png)

## Demonstrated Scenarios

### OTN incident diagnosis and remediation

The primary workflow demonstrates the purpose of the A2U `intent`, `task`,
`plan`, `confirmation`, and notification objects:

1. The OSS discovers NMA capabilities.
2. The OSS invokes `submit-intent` using natural-language or structured input.
3. The NMA creates an intent and task.
4. The NMA invokes Domain Controller functions to retrieve the incident,
   affected service, alarms, and topology.
5. The NMA correlates the context, identifies the probable root cause, and
   generates a recovery plan.
6. The NMA pushes `plan-generated` and `confirmation-required` notifications.
7. The OSS retrieves the full confirmation object and invokes
   `resolve-confirmation`.
8. After approval, the NMA invokes the controller to switch the affected OTN
   service to the protection path and verify recovery.
9. The NMA pushes `step-completed` and `task-completed` notifications and
   exposes the final task result.

Incident information is carried in the A2U `constraints` and confirmation
`context` fields using an `ietf-incident` schema identifier. The A2U model does
not redefine the domain incident model.

### Transport service creation

The secondary workflow demonstrates structured `CREATE` intent submission and
supports confirmation actions including `modify-and-approve`, allowing selected
service parameters to be edited before execution.

## A2U Functions Implemented

### Operational-state resources

| Purpose | Method and RESTCONF-style path |
|---|---|
| Capability discovery | `GET /restconf/data/ietf-nma-a2u:a2u/agent-capabilities` |
| Intent list/object | `GET /restconf/data/ietf-nma-a2u:a2u/intent[={intent-id}]` |
| Task list/object | `GET /restconf/data/ietf-nma-a2u:a2u/task[={task-id}]` |
| Confirmation list/object | `GET /restconf/data/ietf-nma-a2u:a2u/confirmation[={confirmation-id}]` |

### RPC operations

| RPC | Method and RESTCONF-style path |
|---|---|
| Submit intent | `POST /restconf/operations/ietf-nma-a2u:submit-intent` |
| Resolve confirmation | `POST /restconf/operations/ietf-nma-a2u:resolve-confirmation` |
| Abort task | `POST /restconf/operations/ietf-nma-a2u:abort-task` |

The `submit-intent` implementation supports all `intent-type` enumeration values
currently defined by the draft:

`CREATE`, `DELETE`, `MODIFY`, `QUERY`, `REPORT`, `DIAGNOSE`, `REMEDIATE`,
`OPTIMIZE`, and `ASSURE`.

### Notifications

The demo implements the A2U `a2u-task-notification` content, including:

- `plan-generated`;
- `confirmation-required`;
- `step-completed`;
- `step-failed`;
- `task-completed`;
- `task-failed`.

Notification subscription and delivery reuse the dynamic-subscription model in
RFC 8639 and the RESTCONF binding in RFC 8650. After subscription establishment,
the NMA pushes notifications over one long-lived connection; the OSS does not
periodically poll for notifications.

## A2C Demonstration

The Domain Controller page records the NMA-to-controller function sequence used
by the incident workflow:

- `get-incident`;
- `get-service`;
- `get-alarms`;
- `get-topology`;
- `update-incident-analysis`;
- `switch-to-protection`;
- `verify-service`.

The controller provides data access and execution functions. Intent
interpretation, context correlation, root-cause analysis, decision-making,
planning, confirmation handling, and result evaluation remain NMA functions.

## Quick Start

```bash
cd hackathon-demo
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux or macOS
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open:

- Domain Controller and embedded NMA: <http://127.0.0.1:8000/>
- OSS/BSS A2U Client: <http://127.0.0.1:8000/oss>
- A2U-focused OpenAPI page: <http://127.0.0.1:8000/docs>

The demo does not require an external LLM or Internet access.

## Demo Pacing

The workflow deliberately pauses between intent acceptance, context acquisition,
analysis, planning, confirmation, execution, verification, and final feedback so
that each NMA stage can be observed during a live presentation.

The base interval can be adjusted before starting the server:

```bash
# Faster
A2U_DEMO_DELAY_SECONDS=0.7 python app.py

# Slower
A2U_DEMO_DELAY_SECONDS=1.8 python app.py
```

PowerShell example:

```powershell
$env:A2U_DEMO_DELAY_SECONDS="1.8"
python app.py
```

## Testing

```bash
cd hackathon-demo
python tests/smoke_test.py
python tests/api_contract_test.py
```

## Repository Structure

```text
.
├── README.md
├── docs/
│   └── images/
│       ├── domain-controller.png
│       └── oss-a2u-client.png
└── hackathon-demo/
    ├── agent.py
    ├── app.py
    ├── controller.py
    ├── frontend/
    ├── data/
    ├── tests/
    ├── requirements.txt
    └── README.md
```

## Implementation Note

The RESTCONF paths and JSON examples in the demo are intended to illustrate the
A2U YANG model and its workflow. The `/api/demo/*` endpoints and local JSON data
files support the Hackathon user interface and are not part of the A2U YANG
module.
